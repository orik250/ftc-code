package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Gamepad;

@TeleOp(name = "Outake", group = "Linear OpMode")
public class Outake extends LinearOpMode {
    private DcMotorEx flywheel1;
    private DcMotorEx flywheel2;

    private DcMotor intakeMotor;

    public DcMotorEx initializeDcMotorEx(DcMotorEx motorName, String ExconfigMotorName){
        motorName = hardwareMap.get(DcMotorEx.class, ExconfigMotorName);
        motorName.setDirection(DcMotor.Direction.FORWARD);
        motorName.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorName.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        return motorName;
    }
    public DcMotor initializeDcMotorReg(DcMotor motorName, String configMotorName){
        motorName = hardwareMap.get(DcMotor.class, "intakeMotor");
        motorName.setDirection(DcMotor.Direction.FORWARD);
        motorName.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        motorName.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        motorName.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        return motorName;
    }
    @Override
    public void runOpMode(){
        /*flywheel1 = hardwareMap.get(DcMotorEx.class, "flywheelMotor1");
        flywheel1.setDirection(DcMotor.Direction.FORWARD);
        flywheel1.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        flywheel1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flywheel2 = hardwareMap.get(DcMotorEx.class, "flywheelMotor2");
        flywheel2.setDirection(DcMotor.Direction.REVERSE);
        flywheel2.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        flywheel2.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        intakeMotor = hardwareMap.get(DcMotor.class, "intakeMotor");
        intakeMotor.setDirection(DcMotor.Direction.FORWARD);
        intakeMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        intakeMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        intakeMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);*/
        flywheel1 = initializeDcMotorEx(flywheel1, "flywheelMotor1");
        flywheel2 = initializeDcMotorEx(flywheel2, "flywheelMotor2");
        intakeMotor = initializeDcMotorReg(intakeMotor, "intakeMotor");

        waitForStart();

        while(opModeIsActive()){
            if(gamepad1.a){
                flywheel1.setVelocity(100);
                flywheel2.setVelocity(100.0);
            }else {
                flywheel1.setVelocity(0);
                flywheel2.setVelocity(0);
            }
            if(gamepad1.b){
                intakeMotor.setPower(0.5);
            }else{
                intakeMotor.setPower(0);
            }
            if(gamepad1.b){
                intakeMotor.setPower(0.5);
            }else {
                intakeMotor.setPower(0.0);
            }
        }
    }
}
